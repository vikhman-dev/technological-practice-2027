"""Проверка даты рождения и вывод цифр звёздочками. Python 3.12+."""
import argparse
from datetime import date

WEEKDAYS = ('понедельник', 'вторник', 'среда', 'четверг',
            'пятница', 'суббота', 'воскресенье')
DIGITS = {
    '0': ('***', '* *', '* *', '* *', '***'),
    '1': (' * ', '** ', ' * ', ' * ', '***'),
    '2': ('***', '  *', '***', '*  ', '***'),
    '3': ('***', '  *', '***', '  *', '***'),
    '4': ('* *', '* *', '***', '  *', '  *'),
    '5': ('***', '*  ', '***', '  *', '***'),
    '6': ('***', '*  ', '***', '* *', '***'),
    '7': ('***', '  *', '  *', '  *', '  *'),
    '8': ('***', '* *', '***', '* *', '***'),
    '9': ('***', '* *', '***', '  *', '***'),
    ' ': ('   ',) * 5,
}

def is_leap_year(year: int) -> bool:
    if not 1 <= year <= 9999:
        raise ValueError('Год должен быть от 1 до 9999.')
    return year % 400 == 0 or (year % 4 == 0 and year % 100 != 0)

def make_birth_date(day: int, month: int, year: int,
                    today: date | None = None) -> date:
    try:
        birth = date(year, month, day)
    except ValueError as exc:
        raise ValueError('Такой календарной даты не существует.') from exc
    if birth > (today or date.today()):
        raise ValueError('Дата рождения не может быть в будущем.')
    return birth

def weekday_name(birth: date) -> str:
    return WEEKDAYS[birth.weekday()]

def age_on(birth: date, today: date | None = None) -> int:
    """Для 29 февраля в невисокосный год возраст меняется 1 марта."""
    current = today or date.today()
    if birth > current:
        raise ValueError('Дата рождения не может быть в будущем.')
    return current.year - birth.year - (
        (current.month, current.day) < (birth.month, birth.day)
    )

def render_date(birth: date) -> str:
    text = f'{birth.day:02d} {birth.month:02d} {birth.year:04d}'
    return '\n'.join(' '.join(DIGITS[ch][row] for ch in text)
                     for row in range(5))

def read_integer(prompt: str, lower: int, upper: int) -> int:
    while True:
        raw = input(prompt).strip()
        try:
            value = int(raw)
        except ValueError:
            print('Ошибка: введите целое число.')
            continue
        if lower <= value <= upper:
            return value
        print(f'Ошибка: допустимы значения от {lower} до {upper}.')

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--on', type=date.fromisoformat,
                        help='контрольная дата YYYY-MM-DD; по умолчанию сегодня')
    args = parser.parse_args()
    current = args.on or date.today()
    print('Дата рождения')
    while True:
        day = read_integer('День: ', 1, 31)
        month = read_integer('Месяц: ', 1, 12)
        year = read_integer('Год: ', 1, 9999)
        try:
            birth = make_birth_date(day, month, year, current)
            break
        except ValueError as exc:
            print(f'Ошибка: {exc} Повторите ввод даты.')
    print(f'День недели: {weekday_name(birth)}')
    print(f'Високосный год: {"да" if is_leap_year(birth.year) else "нет"}')
    print(f'Полных лет на {current:%d.%m.%Y}: {age_on(birth, current)}')
    print(f'Дата: {birth.day:02d} {birth.month:02d} {birth.year:04d}')
    print(render_date(birth))

if __name__ == '__main__':
    try:
        main()
    except (EOFError, KeyboardInterrupt):
        print('\nВвод завершён.')
