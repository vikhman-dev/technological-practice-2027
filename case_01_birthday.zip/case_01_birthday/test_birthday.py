import unittest
from datetime import date
from birthday import age_on, is_leap_year, make_birth_date, render_date, weekday_name

class BirthdayTests(unittest.TestCase):
    def test_leap_years(self):
        for year, expected in [(1900, False), (2000, True), (2004, True),
                               (2027, False), (2100, False), (2400, True)]:
            with self.subTest(year=year):
                self.assertEqual(is_leap_year(year), expected)

    def test_invalid_year(self):
        for year in (0, 10000):
            with self.subTest(year=year), self.assertRaises(ValueError):
                is_leap_year(year)

    def test_known_weekday(self):
        self.assertEqual(weekday_name(date(2004, 2, 29)), 'воскресенье')

    def test_invalid_calendar_dates(self):
        for args in [(31, 4, 2000), (29, 2, 1900), (0, 1, 2000),
                     (1, 13, 2000), (1, 1, 0)]:
            with self.subTest(args=args), self.assertRaises(ValueError):
                make_birth_date(*args, today=date(2027, 7, 26))

    def test_future_birth(self):
        with self.assertRaises(ValueError):
            make_birth_date(27, 7, 2027, date(2027, 7, 26))

    def test_age_boundary(self):
        birth = date(2000, 7, 26)
        self.assertEqual(age_on(birth, date(2027, 7, 25)), 26)
        self.assertEqual(age_on(birth, date(2027, 7, 26)), 27)

    def test_leap_birthday_policy(self):
        birth = date(2004, 2, 29)
        self.assertEqual(age_on(birth, date(2027, 2, 28)), 22)
        self.assertEqual(age_on(birth, date(2027, 3, 1)), 23)
        self.assertEqual(age_on(birth, date(2028, 2, 29)), 24)

    def test_newborn(self):
        self.assertEqual(age_on(date(2027, 7, 26), date(2027, 7, 26)), 0)

    def test_age_rejects_future(self):
        with self.assertRaises(ValueError):
            age_on(date(2027, 7, 27), date(2027, 7, 26))

    def test_display(self):
        rows = render_date(date(2004, 2, 9)).splitlines()
        self.assertEqual(len(rows), 5)
        self.assertEqual({len(row) for row in rows}, {39})
        self.assertLessEqual(set(''.join(rows)), {'*', ' '})

if __name__ == '__main__':
    unittest.main(verbosity=2)
