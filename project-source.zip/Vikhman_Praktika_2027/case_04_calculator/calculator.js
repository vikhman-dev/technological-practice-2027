"use strict";
const first = document.getElementById("first");
const second = document.getElementById("second");
const result = document.getElementById("result");
const NUMBER_PATTERN = /^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:e[+-]?\d+)?$/i;

function sum(a, b) { return a + b; }
function difference(a, b) { return a - b; }
function product(a, b) { return a * b; }
function division(a, b) {
  if (b === 0) throw new Error("Деление на ноль невозможно.");
  return a / b;
}
const operations = { sum, difference, product, division };

function parseNumber(input, label) {
  const text = input.value.trim();
  input.removeAttribute("aria-invalid");
  if (text === "" || !NUMBER_PATTERN.test(text)) {
    input.setAttribute("aria-invalid", "true");
    throw new Error(`${label}: введите число.`);
  }
  const value = Number(text.replace(",", "."));
  if (!Number.isFinite(value)) {
    input.setAttribute("aria-invalid", "true");
    throw new Error(`${label}: число вне допустимого диапазона.`);
  }
  return value;
}

function calculate(operation) {
  first.removeAttribute("aria-invalid");
  second.removeAttribute("aria-invalid");
  try {
    const a = parseNumber(first, "Первое поле");
    const b = parseNumber(second, "Второе поле");
    const value = operations[operation](a, b);
    if (!Number.isFinite(value)) throw new Error("Результат вне допустимого диапазона.");
    result.classList.remove("error");
    result.textContent = new Intl.NumberFormat("ru-RU", {
      maximumSignificantDigits: 12, useGrouping: false
    }).format(Object.is(value, -0) ? 0 : value);
  } catch (error) {
    result.classList.add("error");
    result.textContent = error.message;
  }
}

document.querySelectorAll("[data-operation]").forEach(button => {
  button.addEventListener("click", () => calculate(button.dataset.operation));
});
