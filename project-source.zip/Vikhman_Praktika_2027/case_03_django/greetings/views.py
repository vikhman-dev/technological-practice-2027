from django.shortcuts import redirect, render
from django.views.decorators.http import require_http_methods
from .forms import NameForm
from .models import Visitor

@require_http_methods(['GET', 'POST'])
def home(request):
    form = NameForm(request.POST if request.method == 'POST' else None)
    if request.method == 'POST' and form.is_valid():
        visitor = form.save()
        request.session['visitor_id'] = visitor.pk
        return redirect('home')
    visitor_id = request.session.get('visitor_id')
    visitor = Visitor.objects.filter(pk=visitor_id).first() if visitor_id else None
    return render(request, 'greetings/home.html', {'form': form, 'visitor': visitor})
