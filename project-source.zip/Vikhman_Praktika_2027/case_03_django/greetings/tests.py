from django.test import Client, TestCase
from django.test.utils import CaptureQueriesContext
from django.db import connection
from .models import Visitor

class GreetingTests(TestCase):
    def test_get_form(self):
        response = self.client.get('/')
        self.assertContains(response, 'csrfmiddlewaretoken')
        self.assertContains(response, 'Submit')
        self.assertEqual(Visitor.objects.count(), 0)

    def test_valid_name_saved(self):
        response = self.client.post('/', {'name': 'Владимир'}, follow=True)
        self.assertContains(response, 'Здравствуйте, Владимир!')
        self.assertEqual(Visitor.objects.get().name, 'Владимир')
        self.assertEqual(response.redirect_chain, [('/', 302)])

    def test_empty_and_whitespace(self):
        for value in ['', '   ', '\t\n']:
            with self.subTest(value=value):
                response = self.client.post('/', {'name': value})
                self.assertContains(response, 'Введите имя.')
        self.assertEqual(Visitor.objects.count(), 0)

    def test_missing_field(self):
        self.assertContains(self.client.post('/', {}), 'Введите имя.')
        self.assertEqual(Visitor.objects.count(), 0)

    def test_name_too_long(self):
        response = self.client.post('/', {'name': 'А' * 81})
        self.assertContains(response, 'не более 80')
        self.assertEqual(Visitor.objects.count(), 0)

    def test_exact_maximum(self):
        self.client.post('/', {'name': 'А' * 80})
        self.assertEqual(len(Visitor.objects.get().name), 80)

    def test_normalization_and_hyphen(self):
        self.client.post('/', {'name': '  Анна-Мария   Ольга  '})
        self.assertEqual(Visitor.objects.get().name, 'Анна-Мария Ольга')

    def test_apostrophe(self):
        self.client.post('/', {'name': "О'Коннор"})
        self.assertEqual(Visitor.objects.get().name, "О'Коннор")

    def test_markup_and_digits_rejected(self):
        for value in ['<script>alert(1)</script>', 'Иван42', '---']:
            with self.subTest(value=value):
                response = self.client.post('/', {'name': value})
                self.assertEqual(response.status_code, 200)
        self.assertEqual(Visitor.objects.count(), 0)

    def test_invalid_value_is_escaped(self):
        response = self.client.post('/', {'name': '<img src=x onerror=alert(1)>'})
        self.assertNotContains(response, '<img src=x')
        self.assertContains(response, '&lt;img')

    def test_csrf_required(self):
        client = Client(enforce_csrf_checks=True)
        response = client.post('/', {'name': 'Владимир'})
        self.assertEqual(response.status_code, 403)
        self.assertEqual(Visitor.objects.count(), 0)

    def test_csrf_valid(self):
        client = Client(enforce_csrf_checks=True)
        client.get('/')
        token = client.cookies['csrftoken'].value
        response = client.post('/', {'name': 'Владимир', 'csrfmiddlewaretoken': token})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Visitor.objects.count(), 1)

    def test_refresh_does_not_duplicate(self):
        self.client.post('/', {'name': 'Владимир'})
        self.client.get('/')
        self.client.get('/')
        self.assertEqual(Visitor.objects.count(), 1)

    def test_clients_do_not_share_greeting(self):
        self.client.post('/', {'name': 'Владимир'})
        response = Client().get('/')
        self.assertNotContains(response, 'Здравствуйте, Владимир!')

    def test_unknown_visitor_id(self):
        session = self.client.session
        session['visitor_id'] = 9999
        session.save()
        self.client.cookies['sessionid'] = session.session_key
        self.assertEqual(self.client.get('/').status_code, 200)

    def test_unsupported_method(self):
        self.assertEqual(self.client.put('/').status_code, 405)

    def test_one_lookup_for_greeting(self):
        self.client.post('/', {'name': 'Владимир'})
        with CaptureQueriesContext(connection) as queries:
            response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(queries), 1)

    def test_only_name_business_field(self):
        business_fields = [f.name for f in Visitor._meta.fields if not f.primary_key]
        self.assertEqual(business_fields, ['name'])
