from django import forms
from .models import Visitor

class NameForm(forms.ModelForm):
    class Meta:
        model = Visitor
        fields = ['name']
        widgets = {'name': forms.TextInput(attrs={
            'placeholder': 'Например, Владимир', 'autocomplete': 'given-name',
            'maxlength': 80, 'aria-describedby': 'name-help',
        })}
        error_messages = {'name': {
            'required': 'Введите имя.',
            'max_length': 'Имя должно содержать не более 80 символов.',
        }}

    def clean_name(self):
        name = ' '.join(self.cleaned_data['name'].split())
        if not name:
            raise forms.ValidationError('Введите имя.')
        if not any(ch.isalpha() for ch in name) or not all(
            ch.isalpha() or ch in " '-’" for ch in name
        ):
            raise forms.ValidationError('Используйте буквы, пробел, дефис или апостроф.')
        return name
