"use strict";
const MIN = -10;
const MAX = 10;
let value = 0;
const result = document.getElementById("result");
const plus = document.getElementById("plus");
const minus = document.getElementById("minus");
const message = document.getElementById("limit-message");

function render() {
  result.textContent = String(value);
  result.className = "result " + (value > 0 ? "positive" : value < 0 ? "negative" : "zero");
  plus.disabled = value === MAX;
  minus.disabled = value === MIN;
  message.textContent = Math.abs(value) === MAX ? "вы достигли экстремального значения" : "";
}

function changeValue(step) {
  value = Math.min(MAX, Math.max(MIN, value + step));
  render();
}

plus.addEventListener("click", () => changeValue(1));
minus.addEventListener("click", () => changeValue(-1));
render();
