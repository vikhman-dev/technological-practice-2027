"""Локальная оценка обработки GET тестовым клиентом Django без сети."""
import json
import os
from pathlib import Path
import platform
import secrets
import statistics
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]

def worker(size):
    sys.path.insert(0, str(ROOT / 'case_03_django'))
    os.environ['DJANGO_SETTINGS_MODULE'] = 'config.settings'
    os.environ['DJANGO_ALLOWED_HOSTS'] = 'testserver,localhost,127.0.0.1'
    import django
    django.setup()
    from django.core.management import call_command
    from django.test import Client
    from django.db import connection
    from django.test.utils import CaptureQueriesContext
    from greetings.models import Visitor
    call_command('migrate', verbosity=0)
    Visitor.objects.bulk_create([Visitor(name='Участник') for _ in range(size)], batch_size=500)
    client = Client()
    client.post('/', {'name': 'Владимир'})
    for _ in range(20):
        client.get('/')
    with CaptureQueriesContext(connection) as queries:
        assert client.get('/').status_code == 200
    durations = []
    for _ in range(200):
        start = time.perf_counter_ns()
        response = client.get('/')
        assert response.status_code == 200
        durations.append((time.perf_counter_ns() - start) / 1_000_000)
    ordered = sorted(durations)
    return {
        'rows': Visitor.objects.count(), 'warmup': 20, 'requests': 200,
        'median_ms': round(statistics.median(durations), 3),
        'p95_ms': round(ordered[189], 3), 'query_count': len(queries),
        'min_ms': round(min(durations), 3), 'max_ms': round(max(durations), 3),
    }

def main():
    if len(sys.argv) == 3 and sys.argv[1] == '--worker':
        print(json.dumps(worker(int(sys.argv[2]))))
        return
    results = []
    with tempfile.TemporaryDirectory() as folder:
        for size in (100, 10000):
            env = os.environ.copy()
            env['DJANGO_DB_PATH'] = str(Path(folder) / f'{size}.sqlite3')
            env['DJANGO_SECRET_KEY'] = secrets.token_urlsafe(50)
            process = subprocess.run([sys.executable, __file__, '--worker', str(size)],
                                     env=env, capture_output=True, text=True, check=True)
            results.append(json.loads(process.stdout))
    output = {
        'method': 'Django Client GET /; sequential; no HTTP network; SQLite',
        'python': platform.python_version(), 'platform': platform.system(),
        'results': results,
    }
    evidence = ROOT / 'evidence'
    evidence.mkdir(exist_ok=True)
    (evidence / 'benchmark.json').write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(output, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
