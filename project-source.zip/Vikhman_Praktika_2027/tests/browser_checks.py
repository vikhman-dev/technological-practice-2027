"""Проверки интерфейсов в Chromium с временной базой и локальными серверами."""
import json
import os
from pathlib import Path
import secrets
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from urllib.error import URLError
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence'
OUT.mkdir(exist_ok=True)
checks = []

def record(name, actual, expected):
    ok = actual == expected
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'passed': ok})
    if not ok:
        raise AssertionError(f'{name}: {actual!r} != {expected!r}')

def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]

def wait_ready(url):
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        try:
            with urlopen(url, timeout=1) as response:
                if response.status == 200:
                    return
        except (URLError, OSError):
            time.sleep(.1)
    raise RuntimeError(f'Сервер не запустился: {url}')

def main():
    web_port, django_port = free_port(), free_port()
    with tempfile.TemporaryDirectory() as temporary, open(os.devnull, 'w') as null:
        env = os.environ.copy()
        env['DJANGO_DB_PATH'] = str(Path(temporary) / 'browser.sqlite3')
        env['DJANGO_SECRET_KEY'] = secrets.token_urlsafe(50)
        subprocess.run([sys.executable, 'manage.py', 'migrate', '--noinput'],
                       cwd=ROOT / 'case_03_django', env=env, stdout=null, check=True)
        servers = []
        try:
            servers.append(subprocess.Popen(
                [sys.executable, '-m', 'http.server', str(web_port), '--bind', '127.0.0.1'],
                cwd=ROOT, stdout=null, stderr=null))
            servers.append(subprocess.Popen(
                [sys.executable, 'manage.py', 'runserver', f'127.0.0.1:{django_port}', '--noreload'],
                cwd=ROOT / 'case_03_django', env=env, stdout=null, stderr=null))
            static_url = f'http://127.0.0.1:{web_port}'
            django_url = f'http://127.0.0.1:{django_port}'
            wait_ready(static_url)
            wait_ready(django_url)
            with sync_playwright() as playwright:
                executable = os.environ.get('BROWSER_EXECUTABLE') or shutil.which('chromium')
                args = {'headless': True}
                if executable:
                    args['executable_path'] = executable
                browser = playwright.chromium.launch(**args)
                page = browser.new_page(viewport={'width': 1024, 'height': 780}, locale='ru-RU')
                errors = []
                page.on('pageerror', lambda err: errors.append(str(err)))
                page.goto(static_url + '/case_02_counter/')
                result = page.locator('#result')
                plus, minus = page.locator('#plus'), page.locator('#minus')
                record('C01 Начальный ноль', result.inner_text(), '0')
                record('C02 Красный фон нуля', result.evaluate('el=>getComputedStyle(el).backgroundColor'), 'rgb(240, 165, 165)')
                record('C03 Скругление кнопки', plus.evaluate('el=>getComputedStyle(el).borderRadius'), '5px')
                record('C04 Градиент фона и кнопки', page.locator('body').evaluate('el=>getComputedStyle(el).backgroundImage.includes("linear-gradient")') and plus.evaluate('el=>getComputedStyle(el).backgroundImage.includes("linear-gradient")'), True)
                plus.click()
                record('C05 Увеличение', result.inner_text(), '1')
                record('C06 Жёлтый положительный', result.evaluate('el=>getComputedStyle(el).backgroundColor'), 'rgb(246, 217, 102)')
                for _ in range(9):
                    plus.click()
                record('C07 Верхняя граница', [result.inner_text(), plus.is_disabled(), minus.is_enabled()], ['10', True, True])
                record('C08 Сообщение на границе', page.locator('#limit-message').inner_text(), 'вы достигли экстремального значения')
                page.locator('main').screenshot(path=str(OUT / 'counter_10.png'))
                minus.click()
                record('C09 Возврат с границы', [result.inner_text(), plus.is_enabled(), page.locator('#limit-message').inner_text()], ['9', True, ''])
                for _ in range(19):
                    minus.click()
                record('C10 Нижняя граница', [result.inner_text(), minus.is_disabled(), plus.is_enabled()], ['-10', True, True])
                record('C11 Зелёный отрицательный', result.evaluate('el=>getComputedStyle(el).backgroundColor'), 'rgb(138, 212, 178)')
                page.locator('main').screenshot(path=str(OUT / 'counter_minus10.png'))
                plus.click()
                record('C12 Возврат с нижней границы', [result.inner_text(), minus.is_enabled()], ['-9', True])
                page.set_viewport_size({'width': 375, 'height': 812})
                record('C13 Нет горизонтальной прокрутки 375px', page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), True)
                page.set_viewport_size({'width': 1024, 'height': 780})
                page.goto(static_url + '/case_04_calculator/')
                record('A01 Результат изначально пуст', page.locator('#result').inner_text(), '')
                def calculate(a, b, operation):
                    page.locator('#first').fill(a)
                    page.locator('#second').fill(b)
                    page.locator(f'[data-operation="{operation}"]').click()
                    return page.locator('#result').inner_text()
                for name, a, b, operation, expected in [
                    ('A02 Сумма', '12.5', '2', 'sum', '14,5'),
                    ('A03 Разность', '5', '8', 'difference', '-3'),
                    ('A04 Произведение', '-2.5', '4', 'product', '-10'),
                    ('A05 Деление', '7', '2', 'division', '3,5'),
                    ('A06 Запятая', '1,5', '2,25', 'sum', '3,75'),
                    ('A07 Нулевое число допустимо', '0', '5', 'sum', '5'),
                    ('A08 Десятичное отображение', '0.1', '0.2', 'sum', '0,3'),
                    ('A09 Экспонента', '1e3', '2', 'product', '2000'),
                    ('A10 Пустой ввод', '', '2', 'sum', 'Первое поле: введите число.'),
                    ('A11 Буквы', 'abc', '2', 'sum', 'Первое поле: введите число.'),
                    ('A12 Частично числовая строка', '12abc', '2', 'sum', 'Первое поле: введите число.'),
                    ('A13 Деление на ноль', '7', '0', 'division', 'Деление на ноль невозможно.'),
                    ('A14 Переполнение результата', '1e308', '1e308', 'product', 'Результат вне допустимого диапазона.'),
                    ('A15 Бесконечный ввод', '1e309', '1', 'sum', 'Первое поле: число вне допустимого диапазона.'),
                    ('A16 Ошибка второго поля', '2', 'text', 'sum', 'Второе поле: введите число.'),
                    ('A17 Лишние разделители', '1,2,3', '1', 'sum', 'Первое поле: введите число.'),
                    ('A18 Пробелы по краям', '  3  ', ' 4 ', 'sum', '7'),
                    ('A19 Отрицательный ноль', '-0', '1', 'product', '0'),
                ]:
                    record(name, calculate(a, b, operation), expected)
                calculate('12,5', '2', 'product')
                page.locator('main').screenshot(path=str(OUT / 'calculator_result.png'))
                calculate('7', '0', 'division')
                page.locator('main').screenshot(path=str(OUT / 'calculator_error.png'))
                calculate('8', '2', 'division')
                record('A20 Восстановление после ошибки', [page.locator('#result').inner_text(), page.locator('#result').get_attribute('class')], ['4', ''])
                page.set_viewport_size({'width': 375, 'height': 812})
                record('A21 Нет горизонтальной прокрутки 375px', page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), True)
                page.set_viewport_size({'width': 1024, 'height': 780})
                page.goto(django_url)
                page.locator('button[type=submit]').click()
                record('D01 Пустое имя в браузере', page.locator('.errors').inner_text(), 'Введите имя.')
                page.locator('main').screenshot(path=str(OUT / 'django_error.png'))
                page.locator('#id_name').fill('Владимир')
                page.locator('button[type=submit]').click()
                record('D02 Приветствие', page.locator('.greeting').inner_text(), 'Здравствуйте, Владимир!')
                page.locator('main').screenshot(path=str(OUT / 'django_greeting.png'))
                page.reload()
                record('D03 Приветствие после обновления', page.locator('.greeting').inner_text(), 'Здравствуйте, Владимир!')
                page.set_viewport_size({'width': 375, 'height': 812})
                record('D04 Нет горизонтальной прокрутки 375px', page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), True)
                record('D05 Нет ошибок JavaScript', errors, [])
                browser.close()
        finally:
            for server in servers:
                server.terminate()
            for server in servers:
                server.wait(timeout=10)
    (OUT / 'browser_results.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'{len(checks)} browser checks passed')

if __name__ == '__main__':
    main()
