"use strict";
// Проверки DOM и обработчиков событий. Геометрия реального браузера не измеряется.
const fs = require("node:fs");
const path = require("node:path");
const assert = require("node:assert/strict");
const { JSDOM } = require("jsdom");
const root = path.resolve(__dirname, "..");
const results = [];
function check(name, actual, expected) {
  assert.deepEqual(actual, expected, name);
  results.push({ name, actual, expected, passed: true });
}
function load(directory, script) {
  const html = fs.readFileSync(path.join(root, directory, "index.html"), "utf8");
  const dom = new JSDOM(html, { runScripts: "outside-only" });
  const style = dom.window.document.createElement("style");
  style.textContent = fs.readFileSync(path.join(root, directory, "styles.css"), "utf8");
  dom.window.document.head.append(style);
  dom.window.eval(fs.readFileSync(path.join(root, directory, script), "utf8"));
  return dom;
}
const counter = load("case_02_counter", "counter.js");
const doc = counter.window.document;
const result = doc.getElementById("result");
const plus = doc.getElementById("plus");
const minus = doc.getElementById("minus");
const notice = doc.getElementById("limit-message");
check("C01 initial zero", result.textContent, "0");
check("C02 zero class", result.classList.contains("zero"), true);
check("C03 zero background", counter.window.getComputedStyle(result).backgroundColor, "rgb(240, 165, 165)");
check("C04 radius 5px", counter.window.getComputedStyle(plus).borderRadius, "5px");
check("C05 exactly two buttons", doc.querySelectorAll("button").length, 2);
plus.click();
check("C06 plus one", result.textContent, "1");
check("C07 positive yellow", counter.window.getComputedStyle(result).backgroundColor, "rgb(246, 217, 102)");
for (let i = 0; i < 9; i++) plus.click();
check("C08 upper boundary", [result.textContent, plus.disabled, minus.disabled], ["10", true, false]);
check("C09 extreme message", notice.textContent, "вы достигли экстремального значения");
for (let i = 0; i < 100; i++) plus.click();
check("C10 cannot exceed maximum", result.textContent, "10");
minus.click();
check("C11 plus reenabled", [result.textContent, plus.disabled, notice.textContent], ["9", false, ""]);
for (let i = 0; i < 19; i++) minus.click();
check("C12 lower boundary", [result.textContent, plus.disabled, minus.disabled], ["-10", false, true]);
check("C13 negative green", counter.window.getComputedStyle(result).backgroundColor, "rgb(138, 212, 178)");
for (let i = 0; i < 100; i++) minus.click();
check("C14 cannot exceed minimum", result.textContent, "-10");
plus.click();
check("C15 minus reenabled", [result.textContent, minus.disabled, notice.textContent], ["-9", false, ""]);
for (let i = 0; i < 9; i++) plus.click();
check("C16 return to zero", [result.textContent, result.classList.contains("zero")], ["0", true]);
const calc = load("case_04_calculator", "calculator.js");
const cd = calc.window.document;
check("A01 initial empty result", cd.getElementById("result").textContent, "");
check("A02 exactly two inputs and four buttons", [cd.querySelectorAll("input").length, cd.querySelectorAll("button").length], [2, 4]);
function calculate(a, b, operation) {
  cd.getElementById("first").value = a;
  cd.getElementById("second").value = b;
  cd.querySelector(`[data-operation="${operation}"]`).click();
  return cd.getElementById("result").textContent;
}
for (const [name, a, b, operation, expected] of [
  ["A03 sum", "12.5", "2", "sum", "14,5"],
  ["A04 difference", "5", "8", "difference", "-3"],
  ["A05 product", "-2.5", "4", "product", "-10"],
  ["A06 division", "7", "2", "division", "3,5"],
  ["A07 decimal comma", "1,5", "2,25", "sum", "3,75"],
  ["A08 zero input", "0", "5", "sum", "5"],
  ["A09 decimal display", "0.1", "0.2", "sum", "0,3"],
  ["A10 exponent", "1e3", "2", "product", "2000"],
  ["A11 empty input", "", "2", "sum", "Первое поле: введите число."],
  ["A12 letters", "abc", "2", "sum", "Первое поле: введите число."],
  ["A13 numeric prefix", "12abc", "2", "sum", "Первое поле: введите число."],
  ["A14 zero divisor", "7", "0", "division", "Деление на ноль невозможно."],
  ["A15 overflow", "1e308", "1e308", "product", "Результат вне допустимого диапазона."],
  ["A16 infinite input", "1e309", "1", "sum", "Первое поле: число вне допустимого диапазона."],
  ["A17 second input error", "2", "text", "sum", "Второе поле: введите число."],
  ["A18 multiple separators", "1,2,3", "1", "sum", "Первое поле: введите число."],
  ["A19 trimmed whitespace", " 3 ", " 4 ", "sum", "7"],
  ["A20 negative zero", "-0", "1", "product", "0"],
  ["A21 incomplete decimal", ".5", "2", "product", "1"],
  ["A22 hexadecimal rejected", "0x10", "2", "sum", "Первое поле: введите число."],
  ["A23 Infinity rejected", "Infinity", "2", "sum", "Первое поле: введите число."],
  ["A24 minus zero divisor", "1", "-0", "division", "Деление на ноль невозможно."],
]) check(name, calculate(a, b, operation), expected);
calculate("8", "2", "division");
check("A25 recovery", [cd.getElementById("result").textContent, cd.getElementById("result").classList.contains("error")], ["4", false]);
check("A26 invalid attribute cleared", [cd.getElementById("first").hasAttribute("aria-invalid"), cd.getElementById("second").hasAttribute("aria-invalid")], [false, false]);
check("A27 result is live region", cd.getElementById("result").getAttribute("aria-live"), "polite");
fs.mkdirSync(path.join(root, "evidence"), { recursive: true });
fs.writeFileSync(path.join(root, "evidence", "javascript_results.json"), JSON.stringify(results, null, 2));
console.log(`${results.length} DOM and JavaScript checks passed`);
